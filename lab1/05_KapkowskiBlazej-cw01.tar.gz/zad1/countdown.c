#include <stdio.h>

void main() {
    for (int i = 10, j = 0; i >= 0; i--, j++) {
        printf("%d %d\n", i, j);
        
    }
}
